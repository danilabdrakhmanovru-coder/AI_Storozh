"""Locally fitted bounded correction to the guard encoder's log odds."""
from functools import lru_cache
import json
import joblib
import numpy as np
from .recipient_model import WEIGHTS,encode,runtime,signals,trained

@lru_cache(maxsize=1)
def config():
    return json.loads((WEIGHTS/'bounded.json').read_bytes())

def combine(values,settings):
    features=values[:,2:]
    adjustment=features @ np.asarray(settings['coef'])+settings['intercept']
    limit=np.where(adjustment<0,settings['negative_cap'],settings['positive_cap'])
    return values[:,0]+limit*np.tanh(adjustment/limit)

@lru_cache(maxsize=1)
def projection():
    return joblib.load(WEIGHTS/'calibration-projection.joblib')

def classify(text):
    cfg=config();x,complete=encode(*runtime(),text)
    vector=signals(trained(),x[None,:],[text])
    if cfg.get('dimensions',0):
        context=projection().transform(x[None,3:])[:,:cfg['dimensions']]
        vector=np.column_stack((vector,context))
    score=float(combine(vector,cfg)[0])
    if score>=cfg['upper']:return 'agent'
    if not complete:return 'uncovered'
    return 'reference' if score<=cfg['lower'] else 'uncertain'

