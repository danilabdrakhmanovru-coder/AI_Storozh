"""One bounded CPU worker per API process. Only model weights are shared between checks."""
import atexit
import multiprocessing
import os
import threading
import time

BUDGET_SECONDS=2.65

class BudgetExceeded(TimeoutError):
    pass

def serve(conn):
    from .contest import ContestRequest,inspect_request,parse_policy,read_policy
    from .category_model import load_current,load_severity
    from .classifier import load_classifier
    from .jailbreak_intent import load as jailbreak_model
    from .request_intent import load as intent_model
    try:
        # A benign probe alone need not traverse every category-dependent branch.
        for load in (load_classifier,load_current,load_severity,jailbreak_model,intent_model):
            load()
        if os.getenv('STOROZH_ATTACHMENT_INTENT')=='8' and os.getenv('STOROZH_VARIANT','B')=='B':
            from .semantic_review import reviewer
            reviewer().assess('Summarize the inventory.')
        if os.getenv('STOROZH_ATTACHMENT_INTENT')=='9' and os.getenv('STOROZH_VARIANT','B')=='B':
            from .intent_review import reviewer
            reviewer().assess('Summarize the inventory.')
        if os.getenv('STOROZH_ATTACHMENT_INTENT') in ('10','11','12','13') and os.getenv('STOROZH_VARIANT','B')=='B':
            from .confidence_review import reviewer
            reviewer()
        raw=read_policy()
        policy=parse_policy(raw)
        agent=next(iter(policy['agents']))
        role=next(iter(policy['agents'][agent]['roles']))
        for content in ('Notes from the inventory.', 'Inventory register.\n'*80):
            dummy=ContestRequest(user_prompt='Summarize the inventory.',context={
                'target_agent':agent,'user_role':role,'attachments':[{'content':content}]})
            inspect_request(dummy,policy['thresholds'],raw)
        conn.send('ready')
        while True:
            packet,limits,policy=conn.recv()
            try:
                value=inspect_request(ContestRequest.model_validate(packet),limits,policy)
                conn.send((True,value))
            except Exception:
                conn.send((False,None))
    except (EOFError,OSError):
        pass
    finally:
        conn.close()

class GuardWorker:
    def __init__(self,target=serve):
        self.lock=threading.Lock()
        self.target=target
        self.proc=None
        self.conn=None

    def _discard(self):
        if self.conn is not None:self.conn.close()
        if self.proc is not None:
            if self.proc.is_alive():self.proc.kill()
            self.proc.join(timeout=.10)
        self.proc=self.conn=None

    def _ready(self,deadline):
        if self.proc is not None and self.proc.is_alive():return
        self._discard()
        ctx=multiprocessing.get_context('spawn')
        self.conn,child=ctx.Pipe()
        self.proc=ctx.Process(target=self.target,args=(child,),daemon=True)
        self.proc.start()
        child.close()
        if not self.conn.poll(max(0.,deadline-time.monotonic())) or self.conn.recv()!='ready':
            raise BudgetExceeded()

    def warm(self):
        with self.lock:
            try:self._ready(time.monotonic()+20)
            except Exception:
                self._discard()
                raise

    def check(self,packet,limits,policy,deadline):
        if not self.lock.acquire(timeout=max(0.,deadline-time.monotonic())):raise BudgetExceeded()
        try:
            self._ready(deadline)
            self.conn.send((packet,limits,policy))
            if not self.conn.poll(max(0.,deadline-time.monotonic())):raise BudgetExceeded()
            ok,result=self.conn.recv()
            if time.monotonic()>deadline:raise BudgetExceeded()
            if not ok:raise RuntimeError('Модель не завершила проверку')
            return result
        except (OSError,EOFError,BudgetExceeded):
            self._discard()
            if self.target is serve:
                threading.Thread(target=self.warm,daemon=True).start()
            raise
        finally:self.lock.release()

    def close(self):
        with self.lock:self._discard()

worker=GuardWorker()
atexit.register(worker.close)

